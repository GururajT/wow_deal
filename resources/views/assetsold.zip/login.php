
<?php include('header.php'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="sign-in-page">
                <div class="row">
                    <!-- Sign-in -->
                    <div class="col-md-6 col-sm-6">
                        <div class="sign-in">
                            <h4 class="">Sign in</h4>
                            <p class="">Hello, Welcome to your account.</p>
                            <form class="register-form outer-top-xs" role="form">
                                <div class="form-group">
                                    <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
                                    <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"> 
                                </div>
                                <div class="form-group">
                                    <label class="info-title" for="exampleInputPassword1">Password <span>*</span></label>
                                    <input type="password" class="form-control unicase-form-control text-input" id="exampleInputPassword1"> 
                                </div>
                                <div class="radio">
                                    <a href="forgot.php" class="forgot-password pull-right">Forgot your Password?</a> 
                                </div>
                                <a href="myaccount.php"><button type="button" class="btn-upper btn btn-primary checkout-page-button">Login</button></a>
                            </form>
                        </div>
                    </div>
                    <!-- Sign-in -->
                    <!-- create a new account -->
                    <div class="col-md-6 col-sm-6">
                        <div class="create-new-account">
                            <h4 class="checkout-subtitle">Create an Account</h4>
                            <p class="text title-tag-line">Personal Information</p>
                            <form class="register-form outer-top-xs" role="form">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="info-title" for="exampleInputEmail1">First Name <span>*</span></label>
                                            <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"> 
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="info-title" for="exampleInputEmail2">Last Name <span>*</span></label>
                                            <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail2"> 
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
                                            <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"> 
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="info-title" for="exampleInputEmail1">Password <span>*</span></label>
                                            <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"> 
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="info-title" for="exampleInputEmail1">Confirm Password <span>*</span></label>
                                            <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"> 
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="info-title" for="exampleInputEmail1">Date of Birth <span>*</span></label>
                                            <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"> 
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="info-title" for="exampleInputEmail1"> Gender  <span>*</span></label>
                                            <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"> 
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn-upper btn btn-primary checkout-page-button">Submit</button>
                            </form>
                        </div>
                    </div>
                    <!-- create a new account -->
                </div>
                <!-- /.row -->
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
