
<?php include('header.php'); ?>

<div class='container'>
    <div class='row single-product'>
        <!-- /.sidebar -->
        <div class='col-md-12'>
            <div class="detail-block">
                <h3 class="new-product-title" style="margin-top: 0; margin-bottom: 25px; font-weight: 700; font-size: 22px; text-align: left; color: #000;"> Category Name </h3>
                <div class="row  wow fadeInUp">
                    <div class="col-xs-12 col-sm-5 col-md-4 gallery-holder">
                        <div class="product-item-holder size-big single-product-gallery small-gallery">
                            <div id="owl-single-product">
                                <div class="single-product-gallery-item" id="slide1">
                                    <a data-lightbox="image-1" data-title="Gallery" href="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                </div>
                                <!-- /.single-product-gallery-item -->
                                <div class="single-product-gallery-item" id="slide2">
                                    <a data-lightbox="image-1" data-title="Gallery" href="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                </div>
                                <!-- /.single-product-gallery-item -->
                                <div class="single-product-gallery-item" id="slide3">
                                    <a data-lightbox="image-1" data-title="Gallery" href="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                </div>
                                <!-- /.single-product-gallery-item -->
                                <div class="single-product-gallery-item" id="slide4">
                                    <a data-lightbox="image-1" data-title="Gallery" href="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                </div>
                                <!-- /.single-product-gallery-item -->
                                <div class="single-product-gallery-item" id="slide5">
                                    <a data-lightbox="image-1" data-title="Gallery" href="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                </div>
                            </div>
                            <!-- /.single-product-slider -->
                            <div class="single-product-gallery-thumbs gallery-thumbs">
                                <div id="owl-single-product-thumbnails">
                                    <div class="item">
                                        <a class="horizontal-thumb active" data-target="#owl-single-product" data-slide="1" href="#slide1"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                    </div>
                                    <div class="item">
                                        <a class="horizontal-thumb" data-target="#owl-single-product" data-slide="2" href="#slide2"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                    </div>
                                    <div class="item">
                                        <a class="horizontal-thumb" data-target="#owl-single-product" data-slide="3" href="#slide3"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                    </div>
                                    <div class="item">
                                        <a class="horizontal-thumb" data-target="#owl-single-product" data-slide="4" href="#slide4"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                    </div>
                                    <div class="item">
                                        <a class="horizontal-thumb" data-target="#owl-single-product" data-slide="5" href="#slide5"> <img class="img-responsive" alt="" src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" data-echo="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" /> </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.gallery-holder -->
                    <div class='col-sm-7 col-md-6 product-info-block'>
                        <div class="product-info">
                            <h1 class="name">Tasty 60 Pieces of Grape Leaves + Musakhen from Royal cake</h1>
                            <p class="paragraph">
                                For every lover of the Arab cuisine, Enjoy delicious 60 Pieces of Grape Leaves + Musakhen from Royal cake Enjoy delicious 60 Pieces of Grape Leaves + Musakhen from Royal cake
                            </p>
                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example12" data-countdown="01/01/2023 05:06:59"></p>
                            <div class="stock-container info-container m-t-10">
                                <div class="row">
                                <div class="col-lg-12">
                                    <div class="pull-left">
                                        <div class="stock-box">
                                            <span class="label">Sold Unit :</span>
                                        </div>  
                                    </div>
                                    <div class="pull-left">
                                        <div class="stock-box">
                                            <span class="value">4</span>
                                        </div>  
                                    </div>
                                    </div>
                                </div><!-- /.row -->    
                            </div>
                            <div class="price-container info-container m-t-20">
                                <div class="row">
                                    <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6">
                                        <div class="price-box"> <span class="price">$800.00</span> <span class="price-strike">$900.00</span> </div>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6">
                                        <div class="add-btn"> <a href="cart.php" class="btn btn-primary"><i class="fa fa-shopping-cart inner-right-vs"></i> Buy Now </a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <div class="product-tabs inner-bottom-xs  wow fadeInUp">
                <div class="row">
                    <div class="col-sm-3">
                        <ul id="product-tabs" class="nav nav-tabs nav-tab-cell">
                            <li class="active"><a data-toggle="tab" href="#description">Deal Details</a></li>
                            <li><a data-toggle="tab" href="#vendor">Location</a></li>
                            <li><a data-toggle="tab" href="#review">What is the Deal</a></li>
                            <li><a data-toggle="tab" href="#tags">Conditions </a></li>
                        </ul>
                        <!-- /.nav-tabs #product-tabs -->
                    </div>
                    <div class="col-sm-9">
                        <div class="tab-content">
                            <div id="description" class="tab-pane in active">
                                <div class="product-tab">
                                    <ul>
                                        <li> <img src="assets/css/images/list_ico.png" /> Valid from: 10 November 2022 </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> Valid to: 10 December 2022 </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> Value: KD7 </li>
                                    </ul>
                                </div>
                            </div>
                            <div id="vendor" class="tab-pane">
                                <div class="product-tab">
                                    <div class="row">
                                        <div class="form-group col-md-4">
                                            <label style="display: block; font-size: 16px;"> Location </label>
                                            <ul>
                                                <li> <img src="https://cdn-icons-png.flaticon.com/512/25/25613.png" /> Free Trade Zone, Kuwait </li>
                                                <li> <img src="https://cdn-icons-png.flaticon.com/512/25/25613.png" /> Free Trade Zone, Kuwait </li>
                                                <li> <img src="https://cdn-icons-png.flaticon.com/512/25/25613.png" /> Free Trade Zone, Kuwait </li>
                                            </ul>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label style="display: block; font-size: 16px;"> Map Location </label>
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3679.9845997119787!2d75.88536997610602!3d22.728813779380737!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962fd47d43f557f%3A0xf04761078255979c!2sOnam%20Plaza%2C%20AB%20Rd%2C%20Near%20Industry%20House%2C%20New%20Palasia%2C%20Indore%2C%20Madhya%20Pradesh%20452001!5e0!3m2!1sen!2sin!4v1668170440529!5m2!1sen!2sin" height="250" style="border:0; width: 100%;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="review" class="tab-pane">
                                <div class="product-tab">
                                    <ul>
                                        <li> <img src="assets/css/images/list_ico.png" /> To inquire: 97754040 </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> Advanced reservation is required </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> Working Times from 9 am to 9 pm </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> Can not be used with another offers </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> No cash back </li>
                                    </ul>
                                </div>
                            </div>
                            <div id="tags" class="tab-pane">
                                <div class="product-tab">
                                    <ul>
                                        <li> <img src="assets/css/images/list_ico.png" /> Coupons will be sent by e-mail only and it can be redeemed by simply showing it on your smartphone or by giving the coupon code over the telephone to the merchant </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> Coupons will be sent by e-mail only and it can be redeemed by simply showing it on your smartphone or by giving the coupon code over the telephone to the merchant </li>
                                        <li> <img src="assets/css/images/list_ico.png" /> Coupons will be sent by e-mail only and it can be redeemed by simply showing it on your smartphone or by giving the coupon code over the telephone to the merchant </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================== RELATED PRODUCTS ============================================== -->
            <section class="section wow fadeInUp">
                <h3 class="section-title">Related Deals</h3>
                <div class="product-slider">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_left_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>-15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Sold 4 Unit </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">420ml Smart Vacuum Flask With LED Temperature Display-White</a></h3>
                                        <div class="description">
                                            <p> Featuring double layer insulation for better maintenance of the liquid inside the flask. Touch the LED  Featuring double layer insulation for better maintenance of the liquid inside the flask. Touch the LED </p>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price"> $ 450.99 </span> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <button class="btn btn-primary cart-btn" type="button">Buy Now</button>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="deals-detail.php"> <button type="button" class="btn btn-primary cart-btn block_btn"> Deals detail </button> </a>
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_right_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/premium-psd/top-view-cosmetics-arrangement_23-2148600666.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>-15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Sold 4 Unit </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example2" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">420ml Smart Vacuum Flask With LED Temperature Display-White</a></h3>
                                        <div class="description">
                                            <p> Featuring double layer insulation for better maintenance of the liquid inside the flask. Touch the LED  Featuring double layer insulation for better maintenance of the liquid inside the flask. Touch the LED </p>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price"> $ 450.99 </span> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <button class="btn btn-primary cart-btn" type="button">Buy Now</button>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="deals-detail.php"> <button type="button" class="btn btn-primary cart-btn block_btn"> Deals detail </button> </a>
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.section -->
            <!-- ============================================== RELATED PRODUCTS : END ============================================== -->
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<style>
.product-info {
    width: 100%;
    padding: 20px 20px;
}
.product-slider{
    margin-top: 25px;
}
</style>
