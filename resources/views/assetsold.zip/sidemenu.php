<ul>
    <li class="myactive"> <a href="myaccount.php"> Dashboard </a> </li>
    <li> <a href="account_info.php"> Account Info </a> </li>
    <li> <a href="myorder.php"> My Orders </a> </li>
    <!-- <li> <a href="javascript:;"> My Coupons </a> </li> -->
    <li> <a href="login.php"> Logout </a> </li>
</ul>