
<?php include('header1.php'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="sidemenu">
                <?php include('sidemenu.php'); ?>
            </div>
        </div>
        <div class="col-md-9">
            <div class="sign-in-page">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="sign-in">
                            <h4 class="">My Dashboard</h4>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Date</th>
                                        <th class="text-center">Order total</th>
                                        <th class="text-center">View Order</th>
                                        <th class="text-center"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><a href="deals-detail.php">#12354</a></td>
                                        <td>22 Jun 2022</td>
                                        <td class="text-center"> $200.00 </td>
                                        <td class="text-center"><a href="order_detail.php" class="btn btn-primary" style="font-size: 10px; padding: 3px 10px; font-weight: 900;"> View </a></td>
                                        <td class="text-center"><a href="https://png.pngtree.com/png-vector/20190330/ourlarge/pngtree-pdf-file-document-icon-png-image_892814.jpg" download target="_blank"> Download now </a></td>
                                    </tr>
                                    <tr>
                                        <td><a href="deals-detail.php">#12354</a></td>
                                        <td>22 Jun 2022</td>
                                        <td class="text-center"> $200.00 </td>
                                        <td class="text-center"><a href="order_detail.php" class="btn btn-primary" style="font-size: 10px; padding: 3px 10px; font-weight: 900;"> View </a></td>
                                        <td class="text-center"><a href="https://png.pngtree.com/png-vector/20190330/ourlarge/pngtree-pdf-file-document-icon-png-image_892814.jpg" download target="_blank"> Download now </a></td>
                                    </tr>
                                    <tr>
                                        <td><a href="deals-detail.php">#12354</a></td>
                                        <td>22 Jun 2022</td>
                                        <td class="text-center"> $200.00 </td>
                                        <td class="text-center"><a href="order_detail.php" class="btn btn-primary" style="font-size: 10px; padding: 3px 10px; font-weight: 900;"> View </a></td>
                                        <td class="text-center"><a href="https://png.pngtree.com/png-vector/20190330/ourlarge/pngtree-pdf-file-document-icon-png-image_892814.jpg" download target="_blank"> Download now </a></td>
                                    </tr>
                                    <tr>
                                        <td><a href="deals-detail.php">#12354</a></td>
                                        <td>22 Jun 2022</td>
                                        <td class="text-center"> $200.00 </td>
                                        <td class="text-center"><a href="order_detail.php" class="btn btn-primary" style="font-size: 10px; padding: 3px 10px; font-weight: 900;"> View </a></td>
                                        <td class="text-center"><a href="https://png.pngtree.com/png-vector/20190330/ourlarge/pngtree-pdf-file-document-icon-png-image_892814.jpg" download target="_blank"> Download now </a></td>
                                    </tr>
                                    <tr>
                                        <td><a href="deals-detail.php">#12354</a></td>
                                        <td>22 Jun 2022</td>
                                        <td class="text-center"> $200.00 </td>
                                        <td class="text-center"><a href="order_detail.php" class="btn btn-primary" style="font-size: 10px; padding: 3px 10px; font-weight: 900;"> View </a></td>
                                        <td class="text-center"><a href="https://png.pngtree.com/png-vector/20190330/ourlarge/pngtree-pdf-file-document-icon-png-image_892814.jpg" download target="_blank"> Download now </a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sign-in-page" style="margin-top: 25px;">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="sign-in">
                            <h4 class=""> Account Information <a style="float: right; font-size: 14px; font-weight: 500; text-decoration: underline;" href="account_update.php"> Edit Profile </a> </h4>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label> Full name </label>
                                        <h6> Rahul Jain </h6>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label> Email Id </label>
                                        <h6> jainrahul@mailinator.com </h6>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label> Phone Number </label>
                                        <h6> 98745635210 </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sign-in-page" style="margin-top: 25px;">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="sign-in">
                            <h4 class=""> Change Password </h4>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label> Old Password </label>
                                        <input type="password" class="form-control" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label> New Password </label>
                                        <input type="password" class="form-control" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label> Confirm Password </label>
                                        <input type="password" class="form-control" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label style="visibility: hidden;"> - </label>
                                        <button type="button" class="btn btn-primary"> Submit </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
