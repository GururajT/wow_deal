
<?php include('header.php'); ?>

<div class="container">
    <div class="row">
        <!-- ============================================== CONTENT ============================================== -->
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div id="product-tabs-slider" class="scroll-tabs wow fadeInUp">
                <div class="more-info-tab clearfix ">
                    <!-- <h3 class="new-product-title pull-left">Most Super Deals</h3> -->
                </div>
                <div class="product-slider">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_left_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_right_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/premium-psd/top-view-cosmetics-arrangement_23-2148600666.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->                                    
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_left_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-photo/stack-clothes-white-background-closeup_93675-132633.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_right_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-photo/stack-clothes-white-background-closeup_93675-132644.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_left_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" alt=""> </a>
                                        </div>
                                        <p style="font-size: 20px; font-weight: 700; position: absolute; right: 25px; margin-top: -66px; background: #ffffff80; padding: 9px 20px;" id="demo"></p>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_right_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/premium-psd/top-view-cosmetics-arrangement_23-2148600666.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_left_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-photo/stack-clothes-white-background-closeup_93675-132633.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_right_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-photo/stack-clothes-white-background-closeup_93675-132644.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_left_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-vector/makeup-cosmetics-accessories-shelf-realistic-image_1284-9312.jpg" alt=""> </a>
                                        </div>
                                        <p style="font-size: 20px; font-weight: 700; position: absolute; right: 25px; margin-top: -66px; background: #ffffff80; padding: 9px 20px;" id="demo"></p>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_right_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/premium-psd/top-view-cosmetics-arrangement_23-2148600666.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_left_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-photo/stack-clothes-white-background-closeup_93675-132633.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="products">
                                <div class="product product_right_bordr">
                                    <div class="product-image">
                                        <div class="image">
                                            <a href="deals-detail.php"> <img src="https://img.freepik.com/free-photo/stack-clothes-white-background-closeup_93675-132644.jpg" alt=""> </a>
                                        </div>
                                        <!-- /.image -->
                                        <div class="tag new"><span>15%</span></div>
                                        <div class="box-timer">
                                            <!-- <h5>Ends On:</h5> -->
                                            <div class="countbox_1 timer-grid"></div>
                                        </div>
                                    </div>
                                    <!-- /.product-image -->
                                    <div class="product-info text-left">
                                        <div class="dataflex">
                                            <div class="brand"> Breakfast & Dinner for 2 Persons at Millennium </div>
                                            <p style="font-size: 20px; font-weight: 500; background: #ffffff80;" id="example1" data-countdown="01/01/2023 05:06:59"></p>
                                        </div>
                                        <h3 class="name"><a href="deals-detail.php">Enjoy Romantic Night in a Deluxe room Including Breakfast & Dinner for 2 Persons at Millennium Centra</a></h3>
                                        <!--  -->
                                        <div class="row falign_down">
                                            <div class="col-md-6">
                                                <div class="product-price"> 
                                                    <span class="price-before-discount">$ 800</span> 
                                                    <span class="price"> $ 450.99 </span> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img class="buynow_btns" src="images/buynow.png" />
                                                <!-- <button class="btn btn-primary cart-btn" type="button">Buy Now</button> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                </div>
                                <!-- /.product -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.scroll-tabs -->
            <!-- ============================================== SCROLL TABS : END ============================================== -->

            <div class="slider-section">
                <div class="col-xs-12 col-sm-12 col-md-12 homebanner-holder">
                    <div id="hero">
                        <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
                            <div class="item" style="background-image: url(assets/images/sliders/03.jpg);">
                                <div class="container-fluid">
                                    <div class="caption bg-color vertical-center text-left">
                                        <div class="slider-header fadeInDown-1">Top Brands</div>
                                        <div class="big-text fadeInDown-1"> New Collections </div>
                                        <div class="excerpt fadeInDown-2 hidden-xs"> <span>Lorem ipsum dolor sit amet, consectetur adipisicing.</span> </div>
                                        <div class="button-holder fadeInDown-3"> <a href="index6c11.html?page=single-product" class="btn-lg btn btn-uppercase btn-primary shop-now-button">Shop Now</a> </div>
                                    </div>
                                    <!-- /.caption -->
                                </div>
                                <!-- /.container-fluid -->
                            </div>
                            <!-- /.item -->
                            <div class="item" style="background-image: url(assets/images/sliders/01.jpg);">
                                <div class="container-fluid">
                                    <div class="caption bg-color vertical-center text-left">
                                        <div class="slider-header fadeInDown-1">Spring 2019</div>
                                        <div class="big-text fadeInDown-1"> Women Fashion </div>
                                        <div class="excerpt fadeInDown-2 hidden-xs"> <span>Nemo enim ipsam voluptatem quia voluptas sit aspernatur.</span> </div>
                                        <div class="button-holder fadeInDown-3"> <a href="index6c11.html?page=single-product" class="btn-lg btn btn-uppercase btn-primary shop-now-button">Shop Now</a> </div>
                                    </div>
                                    <!-- /.caption -->
                                </div>
                                <!-- /.container-fluid -->
                            </div>
                            <!-- /.item -->
                        </div>
                        <!-- /.owl-carousel -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include('footer.php'); ?>