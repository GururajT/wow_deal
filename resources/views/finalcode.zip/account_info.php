
<?php include('header1.php'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="sidemenu">
                <?php include('sidemenu.php'); ?>
            </div>
        </div>
        <div class="col-md-9">
            <div class="sign-in-page">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="sign-in">
                            <h4 class="">Account Info <a href="account_update.php" style="float: right; font-size: 15px; text-decoration: underline;"> Edit Profile </a></h4>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Full name </label>
                                        <h6> Rahul Jain </h6>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Phone Number </label>
                                        <h6> 9874563210 </h6>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Email Adress </label>
                                        <h6> jainrahul@mailinator.com </h6>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Date of Birth </label>
                                        <h6> 15-12-1994 </h6>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Gender </label>
                                        <h6> Male </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
