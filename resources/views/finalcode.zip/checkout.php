
<?php include('header.php'); ?>

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-8">
            <!-- /.breadcrumb -->
            <div>
                <div class="panel-group checkout-steps" id="accordion">
                    <!-- checkout-step-01  -->
                    <div class="panel panel-default checkout-step-01">
                        <!-- panel-heading -->
                        <div class="panel-heading">
                            <h4 class="unicase-checkout-title">
                                <a data-toggle="collapse" id="checkoutBtn" class="" data-parent="#accordion" href="#collapseOne">
                                  <span>1</span> Checkout Method
                                </a>
                            </h4> 
                        </div>
                        <!-- panel-heading -->
                        <div id="collapseOne" class="panel-collapse collapse in">
                            <!-- panel-body  -->
                            <div class="panel-body">
                                <div class="row">
                                    <!-- guest-login -->
                                    <div class="col-md-6 col-sm-6 guest-login">
                                        <h4 class="checkout-subtitle">Guest or Register Login</h4>
                                        <p class="text title-tag-line">Register with us for future convenience:</p>
                                        <!-- radio-form  -->
                                        <form class="register-form" role="form">
                                            <div class="radio radio-checkout-unicase">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <input id="guest" type="radio" name="text" value="guest" checked>
                                                        <label class="radio-button guest-check" for="guest">Checkout as Guest</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        <!-- radio-form  -->
                                        <h4 class="checkout-subtitle outer-top-vs">Register and save time</h4>
                                        <p class="text title-tag-line ">Register with us for future convenience:</p>
                                        <ul class="text instruction inner-bottom-30">
                                            <li class="save-time-reg">- Fast and easy check out</li>
                                            <li>- Easy access to your order history and status</li>
                                        </ul>
                                        <button type="button" id="BillingNext" class="btn-upper btn btn-primary checkout-page-button checkout-continue">Next</button>
                                    </div>
                                    <!-- guest-login -->
                                    <!-- already-registered-login -->
                                    <div class="col-md-6 col-sm-6 already-registered-login">
                                        <h4 class="checkout-subtitle">Already registered?</h4>
                                        <p class="text title-tag-line">Please log in below:</p>
                                        <form class="register-form" role="form">
                                            <div class="form-group">
                                                <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
                                                <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1" placeholder=""> </div>
                                            <div class="form-group">
                                                <label class="info-title" for="exampleInputPassword1">Password <span>*</span></label>
                                                <input type="password" class="form-control unicase-form-control text-input" id="exampleInputPassword1" placeholder=""> <a href="forgot.php" class="forgot-password">Forgot your Password?</a> 
                                            </div>
                                            <a href="myaccount.php"><button type="button" class="btn-upper btn btn-primary checkout-page-button">Login</button></a>
                                                <p style="margin-top: 10px;"> Dont have an account <a href="login.php"> Register now </a></p>
                                        </form>
                                    </div>
                                    <!-- already-registered-login -->
                                </div>
                            </div>
                            <!-- panel-body  -->
                        </div>
                        <!-- row -->
                    </div>
                    <!-- checkout-step-01  -->
                    <!-- checkout-step-02  -->
                    <div class="panel panel-default checkout-step-02">
                        <div class="panel-heading">
                            <h4 class="unicase-checkout-title">
                        <a data-toggle="collapse" class="collapsed" id="billingInfoBtn" data-parent="#accordion" href="#collapseTwo">
                          <span>2</span> Billing Information
                        </a>
                      </h4> </div>
                        <div id="collapseTwo" class="panel-collapse collapse">
                            <div class="panel-body">
                                <form class="register-form" role="form">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="info-title" for="exampleInputEmail1"> First Name <span>*</span></label>
                                                <input type="text" class="form-control unicase-form-control text-input" id="exampleInputEmail1" placeholder=""> 
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="info-title" for="exampleInputPassword1"> Last Name <span>*</span></label>
                                                <input type="text" class="form-control unicase-form-control text-input" id="exampleInputPassword1" placeholder="">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="info-title" for="exampleInputEmail1"> Email Address <span>*</span></label>
                                                <input type="text" class="form-control unicase-form-control text-input" id="exampleInputEmail1" placeholder=""> 
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="info-title" for="exampleInputPassword1"> Telephone <span>*</span></label>
                                                <input type="text" class="form-control unicase-form-control text-input" id="exampleInputPassword1" placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                    <button type="button" id="paymentNext" class="btn-upper btn btn-primary checkout-page-button checkout-continue ">Next</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- checkout-step-02  -->
                    <!-- checkout-step-03  -->
                    <div class="panel panel-default checkout-step-05">
                        <div class="panel-heading">
                            <h4 class="unicase-checkout-title">
                        <a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseFour">
                            <span>4</span> Payment method
                        </a>
                      </h4> </div>
                        <div id="collapseFour" class="panel-collapse collapse">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <div class="radio radio-checkout-unicase">
                                                <input id="Knet" type="radio" name="text" value="guest" checked="">
                                                <label class="radio-button guest-check" for="Knet"> Credit Card / Dabit Card </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- checkout-step-04 -->
                </div>
                <a href="javascript:;" data-toggle="modal" data-target="#myModal">
                    <button type="button" class="btn btn-primary checkout-btn"> Placeorder Now </button>
                </a>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 right-sidebar">
            <div class="checkout-progress-sidebar ">
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="unicase-checkout-title">Review your order</h4> 
                        </div>
                        <div class="panel-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="text-left"> Product </th>
                                        <th class="text-right"> Total </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr><td class="text-left"></td><td class="text-right"></td></tr>
                                    <tr>
                                        <td class="text-left"> 12.9-inch Apple iPad Pro M1 2021 WiFi 128GB-Space Grey </td>
                                        <td class="text-right"> $20.00 </td>
                                    </tr>
                                    <tr>
                                        <td class="text-left"> NICE DRESSx 1 </td>
                                        <td class="text-right"> $20.00 </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="subtotal">
                                <ul>
                                    <li> Subtotal <span> $250.00 </span> </li>
                                    <li> Grand total <span> $225.00 </span> </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<!-- <div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <img style="max-width: 200px; display: block; margin: auto;" src="https://cms-assets.tutsplus.com/cdn-cgi/image/width=850/uploads/users/523/posts/32694/final_image/tutorial-preview-large.png" />
                <h2 style="margin: 0; text-align: center; font-size: 25px; margin-bottom: 35px; font-weight: 900;"> Order Place Success </h2>
                <center>
                    <a href="index.php">
                        <button type="button" class="btn btn-primary checkout-btn"> Back to Home </button>
                    </a>
                </center>
            </div>
        </div>
    </div>
</div> -->

<style>
tbody{
    padding: 10px 0px;
}
tbody td{
    padding: 5px 10px !important;
}
</style>

<script>
$(document).ready(function(){
    $('#BillingNext').click(function(){
        $('#collapseOne').hide();
        $('#collapseTwo').show();
    });
    $('#paymentNext').click(function(){
        $('#collapseTwo').hide();
        $('#collapseFour').show();
    });
    $('#checkoutBtn').click(function(){
        $('#collapseOne').show();
        $('#collapseTwo').hide();
    });
    $('#billingInfoBtn').click(function(){
        $('#collapseTwo').show();
        $('#collapseFour').hide();
    });
});
</script>